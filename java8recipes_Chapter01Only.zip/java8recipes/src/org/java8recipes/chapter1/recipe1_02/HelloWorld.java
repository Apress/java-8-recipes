package org.java8recipes.chapter1.recipe1_02;

/* An object of this class will hold the message. */
class HelloMessage {
    private String greeting = "";
   
    public HelloMessage() {
        this.greeting = "Default Message";
    }
        
    public void setMessage (String m) {
        this.greeting = m;
    }
   
    public String getMessage () {
        return this.greeting.toUpperCase();
    }   
    
}

/* The main program begins in this class */
public class HelloWorld {

    public static void main(String[] args) {
        
        HelloMessage hm;     
        hm = new HelloMessage();
        
        System.out.println(hm.getMessage());
        
        hm.setMessage("Hello, World");
        
        System.out.println(hm.getMessage());    
    }
    
}
